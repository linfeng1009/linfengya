<?php include('system/inc.php');
include('system/cx.php');
if(!file_exists('./install/install.lock')){
header('location:/install/');
}
$x=$_GET['page'];
$url = $cxurl."?p=".$x;
$data=json_decode(file_get_contents($url),true);
$recordcount = $data['page']['recordcount'];
$pagesize = $data['page']['pagesize'];
$seach=file_get_contents('https://www.360kan.com/dianying/index.html');
$szz='#<li class="b-topslidernew-item js-slide-item"(.*?)<a class="" href="https://www.360kan.com/m(.*?)">(.*?)<span class="b-topslidernew-img js-slide-img" style="background-image:url((.*?));"></span>#';
$szz1='#<a class="" href="https://www.360kan.com/m(.*?)">#';
$szz2='#<span class="b-topslidernew-img js-slide-img" style="background-image:url\((.*?)\);"></span>#';
preg_match_all($szz1,$seach,$sarr1);
preg_match_all($szz2,$seach,$sarr2);
$one=$sarr1[1];//链接
$two=$sarr2[1];//图片
include('template/'.$mkcms_bdyun.'/index.php');?>