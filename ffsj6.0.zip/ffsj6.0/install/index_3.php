<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>MKCMS安装向导 - 安装成功</title>
	<link href="css/install.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/common.js"></script>
	<style>.input-note{color: #999; font-size: 12px; padding-top: 2px; line-height: 12px; }</style>
</head>
<body>
<div class="header"></div>
<div class="mainBody">
	<div class="note">
		<div class="complete"><strong>现在您可以：</strong><br />
			<a href="/">访问网站首页</a><span>或</span><a href="/admin/cms_login.php?admin">登录后台</a><p class="input-note">默认用户名密码都是admin，请手动修改admin/cms_login.php文件内的登录参数</p></div>
			
	</div>
	
</div>
</body>
</html>
