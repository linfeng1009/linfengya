<?php
include('system/inc.php');
include('template/'.$mkcms_bdyun.'/mv.php');
?>