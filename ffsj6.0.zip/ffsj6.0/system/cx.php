<?php
$cxurl = $mkcms_cxzy;
?>