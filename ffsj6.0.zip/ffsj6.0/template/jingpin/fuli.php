
<?php $fl='active';?>
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0"/>
<meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
<link rel="stylesheet" href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/zhibo.css">
<link href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/aui.css" rel="styleSheet" type="text/css">
<title>大厅</title>
</head>
<body>
<div id="wrap" class="flex-wrap flex-vertical">	
<div id="main" class="flex-con" >
	<section class="aui-flexView">
	    <section class="aui-scrollView">
			<a href="javascript:;"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/qicai.png" /></a>
	        <div class="aui-tab">
	            <div class="tab-panel">
	                <div class="tab-panel-item tab-active">
	                    <div class="tab-item">
						<a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "zhibo.html";}else {echo "zhibo.php";}?>" class="aui-flex b-line">
	                    <div class="aui-flex-iphone">
	                    <img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/tv.png" alt="">
	                    </div>
	                    <div class="aui-flex-box">
						<p><em class="aui-group-three"> 电视直播</em></p>
	                    <h3>在线收看高清CCTV、卫视</h3>
	                    <p><em class="aui-group-one">实时更新</em> <em class="aui-group-two">电视TV</em></p>
	                    </div>
	                    <div class="aui-flex-support">看直播</div>
	                    </a>
						<a href="<?php if ($mkcms_wei==1){echo 'movie.html';} else{ echo 'movie.php';}?>?m=/dianying/list.php?cat=101&page=1" class="aui-flex b-line">
						<div class="aui-flex-iphone">
	                    <img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/game.png" alt="">
						</div>
						<div class="aui-flex-box">
						<p><em class="aui-group-three"> 伦理影视</em></p>
						<h3>同步各大网站 </h3>
						<p><em class="aui-group-one">不定时更新</em> <em class="aui-group-two">影视院线</em></p>
						</div>
						<div class="aui-flex-support">看电影</div>
						</a>
						<a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yy_27_p1.html';}else{echo 'yy.php?ddst=27_p1';}?>" class="aui-flex b-line">
						<div class="aui-flex-iphone">
						<img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/meinv.png" alt="">
						</div>
						<div class="aui-flex-box">
						<p><em class="aui-group-three"> 美女视频</em></p>
						<h3>YY美女热舞视频</h3>
						<p><em class="aui-group-one">实时更新</em> <em class="aui-group-two">多才多艺</em></p>
						</div>
						<div class="aui-flex-support">看美女</div>
						</a>
						<a href="https://h5.kuaiyinshi.com/" class="aui-flex b-line">
	                    <div class="aui-flex-iphone">
	                    <img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/jh.png" alt="">
	                    </div>
	                    <div class="aui-flex-box">
						<p><em class="aui-group-three"> 快音视频</em></p>
						<h3>抖音快手火山美拍短视频</h3>
	                    <p><em class="aui-group-one">实时更新</em> <em class="aui-group-two">全网火热</em></p>
	                    </div>
	                    <div class="aui-flex-support">看视频</div>
	                    </a>
						<a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'mv.html?sousuo=性感';}else{echo 'mv.php?sousuo=性感';}?>" class="aui-flex b-line">
						<div class="aui-flex-iphone">
						<img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/meinvxiezhen.png" alt="">
						</div>
						<div class="aui-flex-box">
						<p><em class="aui-group-three"> 性感MV</em></p>
						<h3>海量美女性感MV</h3>
						<p><em class="aui-group-one">不定时更新</em> <em class="aui-group-two">全网火热</em></p>
                        </div>
						<div class="aui-flex-support">看MV</div>
						</a>
						</div>
					</div>
				</div>
			</div>
	    </section>
	</section>
</div>
<div id="footer" class="border-t hidden-lg hidden-md" >
<ul class="flex-wrap" style="font-weight:bold">
<a class="flex-con <?php echo $index;?>" href="<?php echo $mkcms_domain;?>"><li onclick="randomSwitchBtn( this );">首页</li>
<a class="flex-con <?php echo $cx;?>" href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>"><li onclick="randomSwitchBtn( this );">抢先</li></a>
<a class="flex-con <?php echo $dt;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'hall.html';}else{echo 'hall.php';}?>"><li onclick="randomSwitchBtn( this );">大厅</li></a>
<a class="flex-con <?php echo $fl;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fuli.html';}else{echo 'fuli.php';}?>"><li onclick="randomSwitchBtn( this );">福利</li></a>
<a class="flex-con <?php echo $hy;?>" href="ucenter"><li onclick="randomSwitchBtn( this );">我的</li></a>
</ul>
 </div>
 </div>
</body>
</html>