<?php include 'head.php';$gx='active';?>
<title>搞笑视频-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="搞笑视频,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'header.php';?>
<div class="container">
<div class="row">
<?php echo get_ad(18)?>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">
<div class="stui-pannel_hd">
<div class="stui-pannel__head active bottom-line clearfix">
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_27.png">搞笑视频</h3></div>
</div>
<!-- 筛选 -->
<ul class="stui-screen__list type-slide clearfix">
<li><span class="text-muted">按类型</span></li>
<?php if ($mkcms_wei==1){ 
echo '<li><a href="./fun_c_94_g__d_1_s_1_p_1.html" >全部</a></li>
<li><a href="./fun_c_94_g_236_d_1_s_1_p_1.html">搞笑自拍</a></li>
<li><a href="./fun_c_94_g_238_d_1_s_1_p_1.html">宠物奇趣</a></li>
<li><a href="./fun_c_94_g_3091_d_1_s_1_p_1.html">影视吐槽</a></li>
<li><a href="./fun_c_86_g__s_1_d_1.html">欢乐街坊</a></li>';}
else{echo '<li><a href="?m=c_94_g__d_1_s_1_p_1" >全部</a></li>
<li><a href="?m=c_94_g_236_d_1_s_1_p_1">搞笑自拍</a></li>
<li><a href="?m=c_94_g_238_d_1_s_1_p_1">宠物奇趣</a></li>
<li><a href="?m=c_94_g_3091_d_1_s_1_p_1">影视吐槽</a></li>
<li><a href="?m=c_86_g__s_1_d_1">欢乐街坊</a></li>';}?>
</ul>
<!-- end 筛选 -->
</div>
<div class="stui-pannel_bd">
<ul class="stui-vodlist clearfix">			
<?php
if (empty($_GET['m'])) {
	$html = "http://list.youku.com/category/video/c_94_d_1_s_1_p_1";
} else {
	$html = "http://list.youku.com/category/video/" . $_GET["m"];
}
$rurl = file_get_contents($html);
$vname = "#<div class=\"yk-col4 \"><div class=\"yk-pack p-list\" taglog=\"\"><div class=\"p-thumb\"><a href=\"(.*?)\" target=\"_blank\" title=\"(.*?)\"></a><i class=\"bg\"></i><img class=\"quic\"  src=\"(.*?)\" alt=\"(.*?)\"/></div><ul class=\"p-info pos-bottom\"><li class=\"status\"><span class=\"p-time hover-hide\"><i class=\"ibg\"></i><span>(.*?)</span></span></li></ul><ul class=\"info-list\"><li class=\"title\"><a href=\"(.*?)\" target=\"_blank\" title=\"(.*?)\">(.*?)</a></li><li class=\" \">(.*?)</li></ul></div></div>#";
preg_match_all($vname, $rurl, $xarr);
$xbflist = $xarr[1];
$xname = $xarr[2];
$ximg = $xarr[3];
$shijian = $xarr[5];
$bofang = $xarr[9];
foreach ($xname as $key => $xvau) {
	$do = $xbflist[$key];
	$do1 = base64_encode($do);	
	$cc = "./splay.php?xiao=";
	$dd="./splay/";
	if ($mkcms_wei==1){
	$html2=".html";
	$ccb = $dd.$do1.$html2;}
	else{
	$ccb = $cc.$do1;	
	}
?>
<li class='col-md-6 col-sm-4 col-xs-3'>
<div class='stui-vodlist__box'>
<a class='stui-vodlist__thumb1 lazyload' href='<?php echo $ccb;?>' title='<?php echo $xname[$key];?>' data-original='<?php echo $ximg[$key];?>'>
<span class='play hidden-xs'></span>
<span class='pic-text text-right'>时长：<?php echo $shijian[$key];?></span></a>
<div class='stui-vodlist__detail'>
<h4 class='title text-overflow'><a href='<?php echo $ccb;?>' title='<?php echo $xname[$key];?>' title='<?php echo $xname[$key];?>'><?php echo $xname[$key];?></a></h4>
<p class='text text-overflow text-muted hidden-xs'><?php echo $bofang[$key];?></p>
</div>
</div>
</li><?php } ?>
</ul>
</div>
</div>
</div>
</div>
<ul class="stui-page text-center cleafix">
<?php
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $html);
curl_setopt($curl, CURLOPT_HEADER, 1);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($curl);
curl_close($curl);
$response = strstr($response, "<div class=\"yk-pager\">");
$response = strstr($response, "<div class=\"vault-banner", true);
$response = str_replace("<div class=\"yk-pager\">", "", $response);
$response = str_replace("</div>", "", $response);
$response = str_replace("<span>", "<a>", $response);
$response = str_replace("<ul class=\"yk-pages\">", "<div monitor-desc='分页' id='js-ew-page' data-block='js-ew-page'  class='ew-page'>", $response);
$response = str_replace("</ul>", "</div>", $response);
$response = str_replace("<span class=\"current\">", "<a class=\"on\">", $response);
$response = str_replace("<li class=\"current\">", "<li class=\"active\">", $response);
$response = str_replace("</span>", "</a>", $response);
if ($mkcms_wei==1){
$response = str_replace("//list.youku.com/category/video/", "fun_", $response);}else{$response = str_replace("//list.youku.com/category/video/", "fun.php?m=", $response);}
$response = str_replace("<a class=\"next\" title=\"下一页\">", "", $response);
$response = str_replace("上一页", "<", $response);
$response = str_replace("下一页", ">", $response);
echo $response;
?></ul>		
<?php  include 'footer.php';?>