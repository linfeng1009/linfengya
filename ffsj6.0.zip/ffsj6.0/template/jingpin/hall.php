
<?php $dt='active';?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="maximum-scale=1.0,minimum-scale=1.0,user-scalable=0,width=device-width,initial-scale=1.0"/>
    <meta name="format-detection" content="telephone=no,email=no,date=no,address=no">
    <title>大厅</title>
    <link rel="stylesheet" type="text/css" href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/iconfont2.css"/>
	<link href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/aui.css" rel="styleSheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/aui2.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/phone_style.css"/>
    <style> 
	body {
    background-repeat: repeat;
    background-size: inherit;
    background-attachment: fixed;
    background-position: center center;
    background: url(/style/bg.jpg);
}
.aui-slide-wrap {
    overflow: hidden;
}
    </style>
</head>
<div id="wrap" class="flex-wrap flex-vertical">	
<div id="main" class="flex-con" >
<div class="br"></div>
<body class="index">
  <div id="aui-slide" class="fx-box">
    <div id="slidebox" class="aui-slide-wrap" style="margin: 10px;border-radius:0.5rem;box-shadow:0.1rem 0.1rem 0.4rem rgba(99, 99, 99, 0.3);">
                  <img id="bpic" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/default_banner.png">
    </div>
  </div>
                                  <div class="list-title">
                                    <div class="list-title-l">
                                      <span style="color:#444;font-size: 0.6rem"><i class="iconfont icon-zuirehotchunse" style="color:#ff7600;font-size: 0.8rem"></i>VIP大厅</span>
                                    </div>
                                    <div class="list-title-r" id="wzbox_top">
                                    </div>
                                  </div>
  <section class="aui-grid aui-margin-b-15">
      <div class="aui-row" id="div_list_f">

	              <div class="aui-col-xs-4 pt-list"><a href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/qiang.png"></i>
                  <div class="aui-grid-label">抢先看</div></a>
                  </div>
				  
                    <div class="aui-col-xs-4 pt-list"><a href="<?php echo $mkcms_domain;?>
                    <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/movie.png"></i>
                    <div class="aui-grid-label">热门电影</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "tv.html";}else {echo "tv.php";}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/juji.png"/></i>
                  <div class="aui-grid-label">电视剧集</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "dongman.html";}else {echo "dongman.php";}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/dongman.png"></i>
                  <div class="aui-grid-label">热血动漫</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "zongyi.html";}else {echo "zongyi.php";}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/zongyi.png"></i>
                  <div class="aui-grid-label">热门综艺</div></a>
                  </div>
                  
                   <div class="aui-col-xs-4 pt-list"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yule.html';}else{echo 'yule.php';}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/yule.png"></i>
                  <div class="aui-grid-label">娱乐资讯</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fun.html';}else{echo 'fun.php';}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/xiao.png"></i>
                  <div class="aui-grid-label">搞笑视频</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'music.html';}else{echo 'music.php';}?>">
                  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/yue.png"></i>
                  <div class="aui-grid-label">在线音乐</div></a>
                  </div>

                  <div class="aui-col-xs-4 pt-list"><a href="fuli.php">
				  <i class="aui-iconfont"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/fu.png"></i>
                  <div class="aui-grid-label">福利</div></a>
                  </div>
      </div>
  </section>
</div>
<div id="footer" class="border-t hidden-lg hidden-md" >
        <ul class="flex-wrap" style="font-weight:bold">
            <a class="flex-con <?php echo $index;?>" href="<?php echo $mkcms_domain;?>"><li onclick="randomSwitchBtn( this );">首页</li>
            <a class="flex-con <?php echo $cx;?>" href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>"><li onclick="randomSwitchBtn( this );">抢先</li></a>
            <a class="flex-con <?php echo $dt;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'hall.html';}else{echo 'hall.php';}?>"><li onclick="randomSwitchBtn( this );">大厅</li></a>
            <a class="flex-con <?php echo $fl;?>" href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fuli.html';}else{echo 'fuli.php';}?>"><li onclick="randomSwitchBtn( this );">福利</li></a>
            <a class="flex-con <?php echo $hy;?>" href="ucenter"><li onclick="randomSwitchBtn( this );">我的</li></a>
        </ul>
 </div>
 </div>
 </body>
</html>