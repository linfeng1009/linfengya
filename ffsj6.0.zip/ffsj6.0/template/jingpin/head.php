<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE10">
<meta name="renderer" content="webkit|ie-comp|ie-stand">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link rel="stylesheet" href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/style.css" type="text/css">
<link href="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/css/aui.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/stui_default.js"></script>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/stui_block.js"></script>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/home.js"></script>
<!--[if lt IE 9]>
<script src="https://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
<script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style type="text/css">
body{
background-repeat:repeat;background-size:inherit;background-attachment:fixed;background-position:center center;background: url(<?php echo $mkcms_beijing;?>); 
}
.stui-header__logo .logo {
display: block;
width: 150px;
height: 50px;
background: url(<?php echo $mkcms_logo;?>) no-repeat;
background-position: 50% 50%;
background-size: cover;
}
@media (max-width:767px){
body:before{background: url() center 0 no-repeat; background-attachment: fixed;background-size: cover;} 	
.stui-header__top{ min-height: 50px;}
.stui-header__logo{ margin-top: 10px; margin-left: 10px;}
}
@media (max-width: 1023px){ 
.stui-header__logo .logo {
width: 90px;
height: 30px;
background: url(<?php echo $mkcms_logo;?>) no-repeat;
background-position: 50% 50%;
background-size: cover;
}}
</style>