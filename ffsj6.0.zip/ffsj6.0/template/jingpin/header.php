<?php include('system/pcon.php');?>
<div id="wrap" class="flex-wrap flex-vertical">
<div id="main" class="flex-con">
<!--head-->
<header class="stui-header__top clearfix" id="header-top">
<div class="container">
<div class="row">
<div class="stui-header_bd clearfix">
<div class="stui-header__logo">
<a class="logo" href="<?php echo $mkcms_domain;?>"></a>
</div>
<ul class="stui-header__menu">
<li class="<?php echo $index;?>"><a href="<?php echo $mkcms_domain;?>">首页</a></li>
<?php if($mkcms_dianying==1){?><li class="<?php echo $movie;?> hidden-xs"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "movie.html";}else {echo "movie.php";}?>">电影</a></li><?php }?>
<?php if($mkcms_dianshi==1){?><li class="<?php echo $tv;?> hidden-xs"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "tv.html";}else {echo "tv.php";}?>">剧集</a></li><?php }?>
<?php if($mkcms_dongman==1){?><li class="<?php echo $dm;?> hidden-xs"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "dongman.html";}else {echo "dongman.php";}?>">动漫</a></li><?php }?>
<?php if($mkcms_zongyi==1){?><li class="<?php echo $zy;?> hidden-xs"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "zongyi.html";}else {echo "zongyi.php";}?>">综艺</a></li><?php }?>
<li><a href="javascript:;">更多 <i class="icon iconfont icon-moreunfold"></i></a>
<ul class="dropdown">
<?php if($mkcms_dianying==1){?><li class="<?php echo $movie;?>"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "movie.html";}else {echo "movie.php";}?>">电影</a></li><?php }?>
<?php if($mkcms_dianshi==1){?><li class="<?php echo $tv;?>"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "tv.html";}else {echo "tv.php";}?>">剧集</a></li><?php }?>
<?php if($mkcms_dongman==1){?><li class="<?php echo $dm;?>"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "dongman.html";}else {echo "dongman.php";}?>">动漫</a></li><?php }?>
<?php if($mkcms_zongyi==1){?><li class="<?php echo $zy;?>"><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "zongyi.html";}else {echo "zongyi.php";}?>">综艺</a></li><?php }?>
<?php if($mkcms_zixun==1){?><li class="<?php echo $yl;?>"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yule.html';}else{echo 'yule.php';}?>">娱乐</a></li><?php }?>
<?php if($mkcms_mv==1){?><li class="<?php echo $mv;?>"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'mv.html';}else{echo 'mv.php';}?>">MV</a></li><?php }?>
<?php if($mkcms_gx==1){?><li class="<?php echo $gx;?>"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fun.html';}else{echo 'fun.php';}?>">搞笑</a></li><?php }?>
<li class="<?php echo $music;?>"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'music.html';}else{echo 'music.php';}?>">音乐</a></li>
<?php if($mkcms_yy==1){?><li class="<?php echo $yy;?>"><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yy.html';}else{echo 'yy.php';}?>">YY</a></li><?php }?>
<?php if($mkcms_qianxian==1){?><li class="<?php echo $cx;?>"><a href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>">尝鲜</a><i class="eb-subhead-hot-icon hidden-xs"></i></li><?php }?>
<li><a href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'zhibo.html';}else{echo 'zhibo.php';}?>">直播</a></li>
<li><a href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'app.html';}else{echo 'app.php';}?>">APP</a></li>
<?php $result = mysql_query('select * from mkcms_nav order by id asc');while($row = mysql_fetch_array($result)) {?>
<li class="act<?php echo $row['id'];?>"><a href="<?php echo $row['n_url'];?>" target="_blank"><?php echo $row['n_name'];?></a></li><?php } ?>
</ul>
</li>
</ul>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>/template/<?php echo $mkcms_bdyun;?>/js/jquery.autocomplete.js"></script>
<div class="stui-header__search">
<form id="search" name="search" method="get" action="<?php echo $mkcms_domain;?>seacher.php?wd=<?php echo $q?>">
<input type="text" id="wd" name="wd" class="mac_wd form-control" value="" placeholder="请输入关键词..."/>
<button class="submit" id="submit" type="submit" onclick="$('#search').submit();"><i class="icon iconfont icon-search"></i></button>
</form>
<a class="search-close visible-xs" href="javascript:;"><i class="icon iconfont icon-close"></i></a>
</div>
<ul class="stui-header__user">
<li>
<?php if($_SESSION['user_name']!=''){?>
<a href="javascript:;"><i class="icon iconfont icon-account"></i></a>
<div class="userdown">
<ul class="history clearfix">
<li><a href="<?php echo $mkcms_domain;?>ucenter/userinfo.php" title="个人设置">个人设置</a></li>
<li class="top-line"><a href="<?php echo $mkcms_domain;?>ucenter/index.php" title="账户中心">账户中心</a></li>
<li class="top-line"><a href="<?php echo $mkcms_domain;?>ucenter/exit.php" title="退出登录">退出登录</a></li>
</ul>
</div>
<?php }else{?>
<a href="<?php echo $mkcms_domain;?>ucenter/login.php"><i class="icon iconfont icon-account"></i></a>
<?php }?>
</li>
<li>
<a href="javascript:;"><i class="icon iconfont icon-clock"></i></a>
<div class="dropdown">
<h5 class="margin-0 text-muted">
<a class="historyclean text-muted pull-right" href="">清空</a>播放记录
</h5>
<ul class="history clearfix" id="stui_history"></ul>
</div>
</li>
<li class="hidden-xs">
<a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "book.html";}else {echo "book.php";}?>"><i class="icon iconfont icon-comments"></i></a>
</li>
<li class="visible-xs">
<a class="open-search" href="javascript:;"><i class="icon iconfont icon-search"></i></a>
</li>
</ul>
</div>
</div>
</div>
</header>
<script type="text/javascript">
	$(".stui-header__user li,.stui-header__menu li").click(function(){
		$(this).find(".dropdown").toggle();
	});
	$(".open-search").click(function(){
		var Seacrh=$(".stui-header__search");
		Seacrh.addClass("active").siblings().hide();
		Seacrh.find(".form-control").focus();
		$(".search-close").click(function(){
			Seacrh.removeClass("active").siblings().show();
		});
	});
</script>
<!--head-->