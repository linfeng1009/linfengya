<?php  include 'head.php';$movie='active'?>
<title>看电影-2018最新好看的最新电影-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="看电影,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
<div class="row">
<?php echo get_ad(11)?>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">
<div class="stui-pannel_hd">
<div class="stui-pannel__head active bottom-line clearfix">
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_27.png">电影</h3></div>
</div>
<!-- 筛选 -->
<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
<li><span class="text-muted">按类型</span></li>
<li><a href="?m=/dianying/list.php?cat=all&page=1">全部</a></li>
<?php
foreach($mcat as $kcat=>$vcat){
$flname=$mname[$kcat];
if ($vcat == 101 || $flname == "伦理") {
echo "";} else {
$flid='/dianying/list.php?cat='.$vcat.'&page=1';
echo "<li><a href='?m=$flid' target='_self'>$flname</a></li>";}}?>
</ul>
<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
<li><span class="text-muted">按地区</span></li>
<li><a href="?m=/dianying/list.php?area=all&page=1">全部</a></li>
<?php
foreach($mcat2 as $kcat=>$vcat){$flname=$mname2[$kcat];
if ($vcat == 13 || $flname == "韩国") {
echo "";} else {
$flid='/dianying/list.php?area='.$vcat.'&page=1';
echo "<li><a href='?m=$flid' target='_self'>$flname</a></li>";}}?>
</ul>
<ul class="stui-screen__list type-slide clearfix">
<li><span class="text-muted">按年份</span></li>
<li><a href="?m=/dianying/list.php?area=all&pageno=1">全部</a></li>
<?php
foreach($mcat1 as $kcat=>$vcat){$flname=$mname1[$kcat];
$flid='/dianying/list.php?year='.$vcat.'&page=1';
echo "<li><a href='?m=$flid' target='_self'>$flname</a></li>";}?>
</ul>
<!-- end 筛选 -->
</div>
<div class="stui-pannel_hd">
<div class="stui-pannel__head active bottom-line clearfix">
				<span class="more text-muted pull-right hidden-xs">千万部VIP视频免费等你观看</span>
				<ul class="nav nav-head">
<?php 
$b=(strpos($_GET['m'],'rank='));
$ye=substr($_GET['m'],$b+5);
?>
<li <?php if ($ye=="rankhot"){echo 'class="active"';}elseif($ye=="createtime" or $ye=="rankpoint"){}else{ echo 'class="active"';};?>><a href="?m=/dianying/list.php?rank=rankhot&page=1">按最热</a></li>
					<li <?php if ($ye=="createtime"){echo 'class="active"';}else{};?>><a href="?m=/dianying/list.php?rank=createtime&page=1">按最新</a></li>
					<li <?php if ($ye=="rankpoint"){echo 'class="active"';}else{};?>><a href="?m=/dianying/list.php?rank=rankpoint&page=1">按好评</a></li>

				</ul>
</div>
</div>
<div class="stui-pannel_bd">
<ul class="stui-vodlist clearfix">
 <?php
$flid1=$_GET['m'];
if ($flid1==""){
$flid1='/dianying/list.php?rank=rankhot&pageno=1';
}
include 'system/360.php';
$i=0;
foreach ($xname as $key=>$xvau){
if ($i<28){
$do=$xlist[$key]; 
$do1=$do; 
$cc="./play.php?play="; 
if ($mkcms_wei==1){
$ccb=vod.$do1;
}
else{
$ccb=$cc.$do1;	
}
echo "<li class='col-md-7 col-sm-4 col-xs-3 ";
if ($i>=27){echo "hidden-xs";}
echo "'><div class='stui-vodlist__box stui-vodlist__bg'>
<a class='stui-vodlist__thumb lazyload' href='".$ccb."' title='".$xvau."' data-original='".$ximg[$key]."'>
<span class='play hidden-xs'></span>";
if (!empty($xfufei[$key])) {echo "<span class='pic-tag pic-tag-h'>".$xfufei[$key]."</span>";}
echo "<span class='pic-tag pic-tag-b'>".$xjishu[$key]."</span></a>
<div class='stui-vodlist__detail  active'>
<h4 class='title text-overflow'><a href='".$ccb."' title='".$xvau."'>".$xvau."</a></h4>
<p class='text text-overflow text-muted hidden-xs'>".$xstar[$key]."</p>
</div>
</div>
</li>"; 
$i ++;
}}?>
</ul>
</div>
</div>
</div>
</div>
<ul class="stui-page text-center cleafix">
<?php include('system/fenye.php');?>
</ul>
<?php  include 'footer.php';?>