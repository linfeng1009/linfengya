<?php include 'head.php';$mv='active';$fl='active';?>
<title>音乐MV-MV音乐排行-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="MV,音悦台,韩国MV,MV下载,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'mvheader.php'; ?>
<div class="container">
<div class="row">
<div class="stui-pannel stui-pannel-bg clearfix">
<?php echo get_ad(19)?>
<div class="stui-pannel-box">
<div class="stui-pannel_hd">
<div class="stui-pannel__head active bottom-line clearfix">
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_27.png">热门MV</h3></div>
</div>
<!-- 筛选 -->
<ul class="stui-screen__list type-slide bottom-line-dot clearfix">
<li><span class="text-muted">按类型</span></li>
<li><a href="/mv.php" >全部</a></li>
<?php if ($mkcms_wei==1){ 
echo '<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=5;12" >舞蹈</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=3%3B10">音乐</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=4%3B11">现场</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=9%3B16">娱乐</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=6%3B13">演奏</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=7%3B14">ACG</a></li>
<li><a href="'.$mkcms_domain.'mv.html?pageno=1&sid=8%3B15">戏剧</a></li>';}
else{echo '<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=5;12" >舞蹈</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=3%3B10">音乐</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=4%3B11">现场</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=9%3B16">娱乐</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=6%3B13">演奏</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=7%3B14">ACG</a></li>
<li><a href="'.$mkcms_domain.'mv.php?pageno=1&sid=8%3B15">戏剧</a></li>';}?>
</ul>
<ul class="stui-screen__list type-slide clearfix">
<li><span class="text-muted">按热门</li>
<?php if ($mkcms_wei==1){ 
echo '<li><a href="'.$mkcms_domain.'mv.html?sousuo=性感">性感</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=热舞">热舞</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=女团">女团</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=饭拍">饭拍</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=鬼步">鬼步</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=高清">高清</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=少女时代">少女时代</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=Sistar">Sistar</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=Apink">Apink</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=Twice">Twice</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=AOA">AOA</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=Girl\'sDay">Girl\'sDay</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=GFRIEND">GFRIEND</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=RedVelvet">RedVelvet</a></li>
<li><a href="'.$mkcms_domain.'mv.html?sousuo=Mamamoo">Mamamoo</a></li>
';} else {echo '<li><a href="'.$mkcms_domain.'mv.php?sousuo=性感">性感</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=热舞">热舞</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=女团">女团</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=饭拍">饭拍</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=鬼步">鬼步</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=高清">高清</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=少女时代">少女时代</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=Sistar">Sistar</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=Apink">Apink</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=Twice">Twice</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=AOA">AOA</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=Girl\'sDay">Girl\'sDay</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=GFRIEND">GFRIEND</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=RedVelvet">RedVelvet</a></li>
<li><a href="'.$mkcms_domain.'mv.php?sousuo=Mamamoo">Mamamoo</a></li>';}?>
</ul>
<!-- end 筛选 -->
</div>
<?php
	if ($_GET["play"]) {
?>
<style>
.html5play iframe{
	height: 560px;
	width: 100%;
}
@media only screen and (max-width:767px){
.html5play iframe{
	    height: 190px;
	width: 100%;
}
}
.html5play iframe{
	background-size: 100%;
}
#xiazai input{
	display: block;
    width: 100%;
	margin-bottom:4px;
    border: 1px solid #204060;
    padding: 6px 8px;
    font-size: 12px;
    border-radius: 2px;
}
</style>
<?php
		$time = $_SERVER["REQUEST_TIME"];
		$queryURL = "http://www.yinyuetai.com/api/info/get-video-urls?callback=callback&videoId=" . $_GET["play"] . "&_=" . $time;
		$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
		$header = array("Accept-Language: zh-cn", "Connection: Keep-Alive", "Cache-Control: no-cache");
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_REFERER, $queryURL);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
		curl_setopt($ch, CURLOPT_URL, $queryURL);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
		$result = curl_exec($ch);
		$result = str_replace("callback(", "", $result);
		$result = str_replace("})", "}", $result);
		$result = json_decode($result, true);
?>
<div class="col-lg-wide-75 col-xs-1">
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">
<div class="html5play">
<iframe id="videourlgo" src="<?php
		if ($_GET["type"] == "hd") {
			echo $result["hdVideoUrl"];
		} else {
			if ($_GET["type"] == "sh") {
				echo $result["heVideoUrl"];
			} else {
				echo $result["hcVideoUrl"];
			}
		}
?>" marginwidth="0" marginheight="0" border="0" scrolling="no" frameborder="0" topmargin="0" width="100%" height="100%"></iframe>
</div>
</div>
</div>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">
<style>
@media (max-width: 767px){.stui-content__playlist.column10 .dyli {width: 30%;margin: 0px 3px;padding: 0px 0px;}}
@media (min-width: 768px){.stui-content__playlist.column10 .dyli {width: 11%;margin: 0px 3px;padding: 0 0px;}}
@media (max-width: 767px){.stui-content__playlist.column10 .zyli {width: 50%;} #dianshijuid img {height: 87px;border-radius: 5px;}}
@media (min-width: 768px){.stui-content__playlist.column10 .zyli {width: 20%;} #dianshijuid img {height: 96px;border-radius: 5px;}}
.stui-vodlist__box img {border-radius: 5px;}
</style>
<div class="stui-pannel_hd">
<div class="stui-pannel__head bottom-line active clearfix">
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_1.png">选择清晰度</h3>
</div>
</div>
<div class="stui-pannel_bd col-pd clearfix dianshijua" id="dianshijuid">
<ul class="stui-content__playlist column10 clearfix">
<?php
		if ($result["hcVideoUrl"]) {
?><li class='dyli'><a  class="btn btn-sm btn-default" onclick="bofang('<?php echo $result["hcVideoUrl"];?>')" href="javascript:()">标清</a></li>
	<?php
		}
		if ($result["hdVideoUrl"]) {
?><li class='dyli'><a class="btn btn-sm btn-default" onclick="bofang('<?php echo $result["hdVideoUrl"];?>')" href="javascript:()">高清</a></li>
	<?php
		}
		if ($result["heVideoUrl"]) {
?><li class='dyli'><a class="btn btn-sm btn-default" onclick="bofang('<?php echo $result["heVideoUrl"];?>')" href="javascript:()">超清</a></li>
	<?php
		}
?>
</ul>
</div>
</div>
</div>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box">
<div class="stui-pannel_hd">
<div class="stui-pannel__head bottom-line active clearfix">
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_7.png">下载地址</h3>
</div>
</div>
<div id="xiazai">
<?php
		if ($result["hcVideoUrl"]) {
?>标清：<input type="text" value="<?php echo $result["hcVideoUrl"];?>"><?php
		}
		if ($result["hdVideoUrl"]) {
?>高清：<input type="text" value="<?php echo $result["hdVideoUrl"];?>"><?php
		}
		if ($result["heVideoUrl"]) {
?>超清：<input type="text" value="<?php echo $result["heVideoUrl"];?>"><?php
		}
?></div>
</div>
</div>
<script type="text/javascript">
	function bofang(mp4url){
	document.getElementById('videourlgo').src = mp4url;
	}
</script>
</div>
<div class="col-lg-wide-25 col-xs-1 stui-pannel-side hidden-sm hidden-xs">
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box clearfix">
<div class="col-pd text-center" style="border: 1px solid #eee; border-radius: 5px;">
<p style="padding: 30px; margin: 0;"><img src="<?php echo $mkcms_appewm;?>"></p><p>下载APP，更方便</p>
</div>
	</div>
</div><!-- 扫码-->
     <div class="stui-pannel stui-pannel-bg clearfix">
      <div class="stui-pannel-box">
       <div class="stui-pannel_hd">
        <div class="stui-pannel__head active bottom-line clearfix">
         <h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_1.png" />影视热度排行榜</h3>
        </div>
       </div>
       <div class="stui-pannel_bd clearfix">
	    <ul class="stui-vodlist__text active col-pd clearfix">
      <?php
	  include './data/bangdan.php';
       foreach ($bdArr['dy']['title'] as $k=>$title){
						
						$bdurl=$bdArr['dy']['url'][$k];//url
						$bdurl = str_replace("http://www.360kan.com", "", $bdurl);
						$bdnum=$bdArr['dy']['num'][$k];//num
                        $topnum=$bdArr['dy']['top'][$k];//topnum
						if ($mkcms_wei==1){
							$chuandi='/vod'.$bdurl;
						}
						else{
							$chuandi='/play.php?play='.$bdurl;	
						}
		  echo "<li class='col-xs-1 padding-0'><a class='text-overflow' href='$chuandi' title='$title'><span class='am-badge am-round pull-left'>$topnum</span><span class='text-muted pull-right'>$bdnum</span><em class='text-red'></em>&nbsp;$title</a></li>";
      }
      ?>
		       </ul>
       </div>
      </div>
     </div>
	 <div class="stui-pannel stui-pannel-bg clearfix">
      <div class="stui-pannel-box">
       <div class="stui-pannel_hd">
        <div class="stui-pannel__head active bottom-line clearfix">
         <h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_2.png" />剧集热度排行榜</h3>
        </div>
       </div>
       <div class="stui-pannel_bd clearfix">
	    <ul class="stui-vodlist__text active col-pd clearfix">
      <?php
	   include './data/bangdan.php';
       foreach ($bdArr['tv']['title'] as $k=>$title){
						$bdurl=$bdArr['tv']['url'][$k];//url
						$bdurl = str_replace("http://www.360kan.com", "", $bdurl);
						$bdnum=$bdArr['tv']['num'][$k];//num
						$topnum=$bdArr['tv']['top'][$k];//topnum
						if ($mkcms_wei==1){
							$chuandi='/vod'.$bdurl;
						}
						else{
							$chuandi='/play.php?play='.$bdurl;	
						}
		  echo "<li class='col-xs-1 padding-0'><a class='text-overflow' href='$chuandi' title='$title'><span class='am-badge am-round pull-left'>$topnum</span><span class='text-muted pull-right'>$bdnum</span>
		 <em class='text-red'></em>&nbsp;$title</a></li>";

      }
      ?>
		</ul>
       </div>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box clearfix">
<div class="col-pd text-center">
<?php echo get_ad(22)?>
</div>
</div>
</div>
      </div>
     </div>
	 </div>
</div></div>
</div></div>
<?php
	} else {
		if ($_GET["sousuo"]) {
			$queryURL = "http://soapi.yinyuetai.com/search/video-search?callback=jQuery110205966153280555879_1497770959887&keyword=" . $_GET["sousuo"] . "&pageIndex=1&pageSize=91&offset=1&orderType=&area=&property=&durationStart=0&durationEnd=&regdateStart=&regdateEnd=1497770974&clarityGrade=&source=&thirdSource=&_=1497770959909";
			$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
			$header = array("Accept-Language: zh-cn", "Connection: Keep-Alive", "Cache-Control: no-cache");
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_REFERER, $queryURL);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
			curl_setopt($ch, CURLOPT_URL, $queryURL);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
			$result = curl_exec($ch);
			$result = str_replace("jQuery110205966153280555879_1497770959887(", "", $result);
			$result = str_replace("})", "}", $result);
			$result = json_decode($result, true);
		} else {
			if ($_GET["sid"]) {
				$sid = $_GET["sid"];
			} else {
				$sid = "";
			}
			if ($_GET["pageno"]) {
				$pageon = $_GET["pageno"];
			} else {
				$pageon = "1";
			}
	$queryURL = "http://mvapi.yinyuetai.com/mvchannel/so?callback=success_jsonpCallback_so&sid=" . $sid."&tid=&a=&p=&c=&s=dayViews&pageSize=30&page=" . $pageon;
			$useragent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)";
			$header = array("Accept-Language: zh-cn", "Connection: Keep-Alive", "Cache-Control: no-cache");
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_REFERER, $queryURL);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
			curl_setopt($ch, CURLOPT_USERAGENT, $useragent);
			curl_setopt($ch, CURLOPT_URL, $queryURL);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 6);
			$result = curl_exec($ch);
			$result = str_replace("success_jsonpCallback_so(", "", $result);
			$result = str_replace("logined\":false})", "logined\":false}", $result);
			$result = json_decode($result, true);
		}
?>
<div class="stui-pannel_bd">
<ul class="stui-vodlist clearfix">
<?php
		if ($_GET["sousuo"]) {
			$url = $result["videos"]["data"][0]["id"];
			$title = $result["videos"]["data"][0]["title"];
			$description = $result["videos"]["data"][0]["description"];
			$image = $result["videos"]["data"][0]["headImg"];
			$duration = $result["videos"]["data"][0]["duration"];
			$videoType = $result["videos"]["data"][0]["videoType"];
			$changdu = count($result["videos"]["data"]);
			$x = 0;
			while ($x < $changdu) {
			$cc="?play=";
			$dd="./mvplay/";
			if ($mkcms_wei==1){
            $ccb=$dd.$result["videos"]["data"][$x]["id"];
            $html=".html";}
			else{
			$ccb=$cc.$result["videos"]["data"][$x]["id"];
			$type="&type=";
			$html=$type.$result["videos"]["data"][$x]["videoType"];}
?>
	<li class="col-md-6 col-sm-4 col-xs-3">
	<div class="stui-vodlist__box">
	<a class='stui-vodlist__thumb1 lazyload' href="<?php echo $ccb.$html;?>" title="<?php echo $result["videos"]["data"][$x]["title"];?>" data-original="http:<?php echo $result["videos"]["data"][$x]["headImg"];?>">
	<span class='play hidden-xs'></span>
	<span class='pic-text text-right'>时长：<?php echo $result["videos"]["data"][$x]["duration"];?></span></a>
	<div class='stui-vodlist__detail'>
<h4 class='title text-overflow'><a href="<?php echo $ccb.$html;?>" title="<?php echo $result["videos"]["data"][$x]["title"];?>"><?php echo $result["videos"]["data"][$x]["title"];?></a></h4>
</div>
</div>
</li>
<?php $x = $x + 1;}} 
else {
			$url = $result["result"][0]["videoId"];
			$title = $result["result"][0]["title"];
			$description = $result["result"][0]["description"];
			$image = $result["result"][0]["image"];
			$artistName = $result["result"][0]["artists"][0]["artistName"];
			$duration = $result["result"][0]["duration"];
			$videoType = $result["result"][0]["videoType"];
			$changdu = count($result["result"]);
			$x = 0;
			while ($x < $changdu) {
			$cc="?play=";
			$dd="./mvplay/";
			if ($mkcms_wei==1){
            $ccb=$dd.$result["result"][$x]["videoId"];
            $html=".html";}
			else{
			$ccb=$cc.$result["result"][$x]["videoId"];
			$type="&type=";
			$html=$type.$result["result"][$x]["videoType"];}	
?>
	<li class="col-md-6 col-sm-4 col-xs-3">
	<div class="stui-vodlist__box">
	<a class='stui-vodlist__thumb1 lazyload' href="<?php echo $ccb.$html;?>" title="<?php echo $result["result"][$x]["title"];?>" data-original="http:<?php echo $result["result"][$x]["image"];?>">
	<span class='play hidden-xs'></span>
	<span class='pic-text text-right'>时长：<?php echo $result["result"][$x]["duration"];?></span></a>
	<div class='stui-vodlist__detail'>
<h4 class='title text-overflow'><a href="<?php echo $ccb.$html;?>" title="<?php echo $result["result"][$x]["title"];?>"><?php echo $result["result"][$x]["title"];?></a></h4>
<p class='text text-overflow text-muted hidden-xs'>艺人：<?php echo $result["result"][$x]["artists"][0]["artistName"];?></p>
</div>
</div>
</li>
<?php $x = $x + 1;}}?>
</ul>
</div>
</div>
</div>
</div>
<?php
		if (!$_GET["sousuo"]) {
			$pageon = $pageon + 1;
?>
<ul class="stui-page text-center cleafix"><div monitor-desc="分页" id="js-ew-page" data-block="js-ew-page" class="ew-page"><li class="active"><a href="javascript:history.go(-1);">上一页</a></li><li class="active"><a href="?pageno=<?php echo $pageon;?><?php if ($_GET["sid"]) {
				echo "&sid=".$_GET["sid"];
			}?>">下一页</a></li></div></ul>
<?php } ?>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/history.js"></script>
<script type="text/javascript">var vod_name='<?php echo $yname[$key];?>',vod_url=window.location.href,vod_part='1';</script>
<?php } include 'footer.php';?>