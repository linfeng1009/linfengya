<?php  include 'head.php';$yy='active';?>
<title>YY舞曲-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="<?php echo $data['data'][0]['vod_name'];?>,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $data['data'][0]['vod_name'];?>,<?php echo $mkcms_description;?>">
<style type="text/css">
#timer{background: rgba(0, 0, 0, 0.59);padding: 5px;text-align: center;width: 30px;position: absolute;top: 5%;right: 2%;color: #fff;font-size: 16px;border-radius: 50%;height: 30px;line-height: 20px}
#xiang{background: rgba(177, 13, 13, 0.87);padding: 5px;text-align: center;width: auto;position: absolute;bottom: 2%;right: 1%;color: #fff;font-size: 16px;border-radius: 10px;height: 20px;line-height: 9px}
#ys,.jkbtn{border: 1px solid #FF9900;background-color: #FF9900;color: #FFFFFF;}
.stui-player__video {margin-bottom: 10px;}
</style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
<div class="row">
<div class="col-lg-wide-75 col-xs-1">
<div class="stui-player__item clearfix">
<div class="stui-player__video embed-responsive embed-responsive-16by9 clearfix">
<div id="shiping_box"></div>
<?php
ini_set('user_agent','Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; .NET CLR 1.1.4322)');
$arta= file_get_contents('http://www.yy.com/shenqu/show/info.do?resid=' .$_GET['post']. '');
$uu1 = '#"resurl":"(.*?)"#';
preg_match_all($uu1,$arta, $lj);
$bf = $lj[1];
foreach ($bf as $gg => $qz1){
?>
<script type="text/javascript">
            function run(){
			var s = document.getElementById("timer");
		if(!s){
			return false;
			}else{
			s.innerHTML = s.innerHTML * 1 - 1;
		 }
		}
	window.setInterval("run();", 1000);
	$('#shiping_box').html('<div style="text-align:center;width:100%;"><?php echo get_ad(1)?></div><div id="timer"><?php echo $mkcms_miaoshu;?></div>');
	//设置延时函数
	function adsUp(){
        $("#shiping_box").html('<iframe id="video" src="<?php echo $mkcms_domain;?>ck/index.php?url=<?php echo $qz1;?>"  allowfullscreen="true" allowtransparency="true" style="width:100%;border:none"></iframe>');
    }
    //五秒钟后自动收起
    var t = setTimeout(adsUp,<?php echo $mkcms_miaoshu*1000;?>);   
</script>
<?php }?>
</div>
<?php 
$url = file_get_contents('http://www.yy.com/shenqu/show/info.do?resid=' .$_GET['post']. '');
$lname ='#"songName":"(.*?)"#';
$aname ='#"anchorName":"(.*?)"#';
preg_match_all($lname,$url, $xarr);
preg_match_all($aname,$url, $xarr1);
$xname = $xarr[1];
$bname = $xarr1[1];
foreach ($xname as $cc => $dd){
	$ee=$bname[$cc];
?>
<div class="stui-player__detail detail" id="dianshijuid">
<h1 class="title" id="xuji"><a><?php echo $dd;?>-<?php echo $ee;?></a><span class="js"></span></h1>
</div>
<?php }?>
</div>
<!-- 播放器-->
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box b playlist mb">
<div class="stui-pannel_hd">
<div class="stui-pannel__head bottom-line active clearfix">
<span class="more text-muted pull-right">无需安装任何插件，即可快速播放</span>
<h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_7.png">播放列表</h3>
</div>
</div>
<div class="stui-pannel_bd col-pd clearfix dianshijua" id="dianshijuid">
<ul class="stui-content__playlist column6 clearfix">
<?php
$url2 = file_get_contents('http://www.yy.com/shenqu/play/id_' .$_GET['post']. '.html');
$link1 ='#<a class="v-related__item" href="(.*?)" data-url="(.*?)" data-title="(.*?)">#';
$img1 ='#<img src="(.*?)?ips_thumbnail/4/0/w/220/h/124/blur/1/format=jpg" alt="(.*?)">#';
preg_match_all($link1,$url2,$ff1);
preg_match_all($img1,$url2,$ff2);
$link2 = $ff1[1];
$ximg = $ff2[1];
$title = $ff1[3];
$xlink = str_replace('/shenqu/play/id_','', $link2);
foreach ($title as $key => $xvau) {
	$do1 = $xlink[$key];
	if ($mkcms_wei==1){
	$do='/yplay/'.$do1;
	}else{
	$do3 = str_replace('.html','', $do1);
	$do = 'yplay.php?post='.$do3;
	}
?>
<li class='zyli'><a href='<?php echo $do;?>' class='btn btn-danger btn-play-source 1'><img src='<?php echo $ximg[$key];?>' class='lazyload'  height='70px'><br><?php echo $xvau;?></a></li>
<?php } ?>
</ul>
</div>
</div>
</div>
<!-- 播放地址-->
</div>
<div class="col-lg-wide-25 col-xs-1 stui-pannel-side hidden-sm hidden-xs">
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box clearfix">
<div class="col-pd text-center" style="border: 1px solid #eee; border-radius: 5px;">
<p style="padding: 30px; margin: 0;"><img src="<?php echo $mkcms_appewm;?>"></p><p>下载APP，更方便</p>
</div>
	</div>
</div><!-- 扫码-->
     <div class="stui-pannel stui-pannel-bg clearfix">
      <div class="stui-pannel-box">
       <div class="stui-pannel_hd">
        <div class="stui-pannel__head active bottom-line clearfix">
         <h3 class="title"><img src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/img/icon_1.png" />影视热度排行榜</h3>
        </div>
       </div>
       <div class="stui-pannel_bd clearfix">
	    <ul class="stui-vodlist__text active col-pd clearfix">
      <?php
	  include './data/bangdan.php';
       foreach ($bdArr['dy']['title'] as $k=>$title){
						
						$bdurl=$bdArr['dy']['url'][$k];//url
						$bdurl = str_replace("http://www.360kan.com", "", $bdurl);
						$bdnum=$bdArr['dy']['num'][$k];//num
                        $topnum=$bdArr['dy']['top'][$k];//topnum
						if ($mkcms_wei==1){
							$chuandi='/vod'.$bdurl;
						}
						else{
							$chuandi='/play.php?play='.$bdurl;	
						}
		  echo "<li class='col-xs-1 padding-0'><a class='text-overflow' href='$chuandi' title='$title'><span class='am-badge am-round pull-left'>$topnum</span><span class='text-muted pull-right'>$bdnum</span><em class='text-red'></em>&nbsp;$title</a></li>";
      }
      ?>
		       </ul>
       </div>
<div class="stui-pannel stui-pannel-bg clearfix">
<div class="stui-pannel-box clearfix">
<div class="col-pd text-center">
<?php echo get_ad(22)?>
</div>
</div>
</div>
      </div>
     </div>
	 </div>
</div>
</div>
<script type="text/javascript" src="<?php echo $mkcms_domain;?>template/<?php echo $mkcms_bdyun;?>/js/history.js"></script>
<script type="text/javascript">var vod_name='<?php echo $yname[$key];?>',vod_url=window.location.href,vod_part='1';</script>
<?php include 'footer.php'; ?>