<?php include('chk.php');?>
<header class="navbar">		
		<div class="container">			
			<div class="clearfix navbar-top">				
				<a href="<?php echo $mkcms_domain;?>"><img src="<?php echo $mkcms_logo;?>" class="pull-left logo-left"></a>				
				<button class="navbar-toggle pull-left" type="button" data-toggle="collapse" data-target=".navbar-collapse">		
					<span class="sr-only">Toggle navigation</span>			
					<span class="icon-bar"><i class="iconfont icon-gengduo"></i></span>		
					<span class="icon-bar"></span>				
					<span class="icon-bar"></span>				
				</button>				
				<form class="navbar-form hidden-xs" role="search" action="<?php echo $mkcms_domain;?>seacher.php" method="post">					
					<div class="form-group">					
						<input type="search" placeholder="搜索视频" class="form-control js-search" name="wd">				
					</div>					
					<button type="submit" class="button iconfont icon-search"></button>				
				</form>							
				<div class="navbar-user pull-right visible-xs"  style="top:16px;" >					
				<?php if($_SESSION['user_name']!=''){?>						
					<ul class="nav navbar-nav navbar-right">														
						<li class="info-img">
							<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> 		
								<span><?php echo $_SESSION['user_name'];?></span> <i class="iconfont icon-xia"></i> 
							</a>								
									<ul class="dropdown-menu menu-ul" role="menu">									
										<li><a href="userinfo.php"><i class="iconfont icon-shezhi"></i>个人设置</a></li>		
										<li><a href="index.php"><i class="iconfont icon-001"></i> 账户中心</a></li>	
										<li><a href="exit.php"><i class="iconfont icon-tuichu"></i>退出登录</a></li>										
									</ul>								
						</li>					
					</ul>					
					
				<?php }?>				
				</div>			
			</div>		
		</div>		
		<nav class="nav-collapse">			
			<div class="container">				
				<div class="navbar-header">					
					<ul class="nav navbar-left navbar-collapse collapse">						
						<li <?php echo $index;?>><a href="<?php echo $mkcms_domain;?>">首页</a></li>
<?php if($mkcms_dianying==1){?><li <?php echo $movie;?>><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "movie.html";}else {echo "movie.php";}?>">电影</a></li><?php }?>
<?php if($mkcms_dianshi==1){?><li <?php echo $tv;?>><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "tv.html";}else {echo "tv.php";}?>">剧集</a></li><?php }?>
<?php if($mkcms_dongman==1){?><li <?php echo $dm;?>><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "dongman.html";}else {echo "dongman.php";}?>">动漫</a></li><?php }?>
<?php if($mkcms_zongyi==1){?><li <?php echo $zy;?>><a href="<?php echo $mkcms_domain;?><?php if ($mkcms_wei==1){ echo "zongyi.html";}else {echo "zongyi.php";}?>">综艺</a></li><?php }?>
<?php if($mkcms_zixun==1){?><li <?php echo $yl;?>><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yule.html';}else{echo 'yule.php';}?>">娱乐</a></li><?php }?>
<?php if($mkcms_mv==1){?><li <?php echo $mv;?>><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'mv.html';}else{echo 'mv.php';}?>">MV</a></li><?php }?>
<?php if($mkcms_gx==1){?><li <?php echo $gx;?>><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'fun.html';}else{echo 'fun.php';}?>">搞笑</a></li><?php }?>
<li <?php echo $music;?>><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'music.html';}else{echo 'music.php';}?>">音乐</a></li>
<?php if($mkcms_yy==1){?><li <?php echo $yy;?>><a href="<?php if($mkcms_wei==1){echo $mkcms_domain.'yy.html';}else{echo 'yy.php';}?>">YY</a></li><?php }?>
<?php if($mkcms_qianxian==1){?><li <?php echo $cx;?>><a href="<?php if ($mkcms_wei==1){echo $mkcms_domain.'cx.html';}else{echo 'cx.php';}?>">尝鲜</a><i class="eb-subhead-hot-icon hidden-xs"></i></li><?php }?>
<?php $result = mysql_query('select * from mkcms_nav order by id asc');
      while($row = mysql_fetch_array($result)) {?>
<li class="act<?php echo $row['id'];?>"><a href="<?php echo $row['n_url'];?>" target="_blank"><?php echo $row['n_name'];?></a></li>
<?php } ?>
					</ul>				
				</div>				
				<div class="navbar-user hidden-xs">				
					<ul class="nav navbar-nav navbar-right">						
					<?php if($_SESSION['user_name']!=''){?>				
						<ul class="nav navbar-nav navbar-right">							
													
								<li class="info-img">
									<a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"> 				
				
											<img src="images/093958e59110293063.jpg" class="img-circle" />		
								
										<span><?php echo $_SESSION['user_name'];?></span> <i class="iconfont icon-xia"></i> 
									</a>									
									<ul class="dropdown-menu menu-ul" role="menu">								
										<li><a href="userinfo.php"><i class="iconfont icon-shezhi"></i>个人设置</a></li>		
										<li><a href="index.php"><i class="iconfont icon-001"></i> 账户中心</a></li>	
										<li><a href="exit.php"><i class="iconfont icon-tuichu"></i>退出登录</a></li>	
									</ul>								
								</li>						
						</ul>					
					
<?php }?>					
					</ul>				
				</div>			
			</div>		
		</nav>    
	</header>  
