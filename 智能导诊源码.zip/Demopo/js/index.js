			
			//女为0，男为1  默认为男     age1表示大人   0小孩 默认成人  face 1是正面 0是反面
			var sex=1;
			var age=1;
			var face=1;
//			Class颜色跳转
			$(".nav-right").click(function() {
				$(".nav-left").removeClass("active-click");
				$(this).addClass("active-click");
				$(".con2").css("display","none");
				$(".list-li").css("display","block")
			})
			$(".nav-left").click(function() {
				$(".nav-right").removeClass("active-click");
				$(this).addClass("active-click");
				$(".con2").css("display","block");
				$(".list-li").css("display","none")
			});
			
			$("#app").on("click","#sex-man",function(){
				face=1;
				$("#sex-woman").removeClass("active-click");
				$(this).addClass("active-click");
				if(age==1){
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/MMZ.png");
						$(".img>img").stop().fadeIn(800);
					});
					age=1;
					sex=1;
				}else if(age==0){
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/CBZ.png");
						$(".img>img").stop().fadeIn(800);
					});
					sex=1;
					age=0;
				}
				IsAc();
				Isface();
			})
			$("#app").on("click","#sex-woman",function(){
				face=1;
				$("#sex-man").removeClass("active-click");
				$(this).addClass("active-click");
				if(age==0){
					age=0;
					sex=0;
					IsAc();
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/CGZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}else if(age==1){
					age=1;
					sex=0;
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/FMZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}
				IsAc();
				Isface();
			})
			$("#app").on("click","#adult",function(){
				face=1;
				$("#child").removeClass("active-click");
				$(this).addClass("active-click");
				if(sex==1){
					sex=1;
					age=1;
					IsAc();
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/MMZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}else if(sex==0){
					sex=0;
					age=1;
					IsAc();
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/FMZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}
				IsAc();
				Isface();
			});
			$("#app").on("click","#child",function(){
				face=1;
				age=0;
				$("#adult").removeClass("active-click");
				$(this).addClass("active-click");
				if(sex==1){
					sex=1;
					IsAc();
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/CBZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}else if(sex==0){
					sex=0;
					age=0;
					IsAc();
					$(".img>img").stop().fadeOut(800,function(){
						$(".img>img").attr("src","img/CGZ.png");
						$(".img>img").stop().fadeIn(800);
					});
				}

				IsAc();
				Isface();
			});
			
			//获取鼠标点的坐标
//			document.onmousedown = getMouseXY;
//			function getMouseXY(e) {
//				tempX = event.clientX  
//			    tempY = event.clientY
//			    console.log(e);
//			  	console.log("x坐标:"+tempX+" y坐标："+tempY);
//			  	var a=$(".img-responsive").height();
//			}

		
			$(".head").click(function(){
					var title="头部";
					var Arr=["腮腺肿大","耳痛","头痛","头晕","面部疼痛","语言障碍"];
					getData(title,Arr)
					$(".zindex").css("display","block");
					$(".dis").stop().animate({width:'toggle'},500);
			});
			$(".neck").click(function(){
				Isface();
				try
				{
					var title="颈部";
					if(age==1&&face!=0||age==0&&sex==0&&face!=0){
						var Arr=["颈部疼痛或僵硬","咽喉疼痛","甲状腺肿大","吞咽困难","咳痰"];
					}else if(age==0&&sex==1&&face!=0){
						var Arr=["颈部疼痛或僵硬","咽喉疼痛","甲状腺肿大","吞咽困难"];
					}
						getData(title,Arr)
						$(".zindex").css("display","block");
						$(".dis").stop().animate({width:'toggle'},500);
				}
				catch
				{
					console.log("%c这是个数组参数为undefinded,导致length的异常的判断,无视就行了------by临枫", "color:red;")
				}
			});
			$(".chest").click(function(){
				Isface();
			try
			{
			    var title="胸部";
				if(sex==1&&face==1){
					var Arr=["心悸","胸痛","咳嗽","肩部疼痛","呼吸困难","咯血","喘鸣"];
				}else if(sex==0&&face==1){
					var Arr=["心悸","胸痛","咳嗽","肩部疼痛","呼吸困难","咯血","喘鸣","乳房疼痛","乳房肿块"];
				}
				getData(title,Arr)
				$(".zindex").css("display","block");
				$(".dis").stop().animate({width:'toggle'},500);
			  }
			catch
			{
				console.log("%c这是个数组参数为undefinded,导致length的异常的判断,无视就行了------by临枫", "color:red;")
			}
				
			});
			$(".belly").click(function(){
			Isface();
			if(face==1){
				var title="腹部";
				var Arr=["呃逆","食欲异常","腹泻","胃肠胀气","恶心呕吐","呕血与黑便","反酸","腹痛","肝脏"];
				getData(title,Arr)
				$(".zindex").css("display","block");
				$(".dis").stop().animate({width:'toggle'},500);
			}
			});
			
			$(".genitals").click(function(){
				Isface();
				
				try
			{
				var title="生殖器";
				if(sex==1&&age==1&&face==1||sex==1&&age==0&&face==1){
					var Arr=["早泄","阳痿","因囊肿物","包皮长"];
				}else if(sex==0&&age==1&&face==1||age==0&&sex==0&&face==1){
					var Arr=["痛经","月经不调","白带异常","月经过多","阴道出血","闭经"];
				}
				
				getData(title,Arr)
				$(".zindex").css("display","block");
				$(".dis").stop().animate({width:'toggle'},500);
				}
			catch
			{
				console.log("%c这是个数组参数为undefinded,导致length的异常的判断,无视就行了------by临枫", "color:red;")
			}
				
			});
			$(".arm,.arm2").click(function(){
				var title="上肢";
				var Arr=["手腕疼痛"];
				getData(title,Arr)
				$(".zindex").css("display","block");
				$(".dis").stop().animate({width:'toggle'},500);
			});
			$(".legs").click(function(){
				var title="下肢";
				if(sex==1&&age==1){
					var Arr=["髋关节疼痛","膝关节疼痛","踝部肿胀","髋关节疼痛","膝关节疼痛"];
				}else{
					var Arr=["髋关节疼痛","膝关节疼痛","踝部肿胀"];
				}
				getData(title,Arr)
				$(".zindex").css("display","block");
				$(".dis").stop().animate({width:'toggle'},500);
			});
			$(".cl").click(function(){
				$(".dis").stop().animate({width:'hide'},500);
				$(".zindex").stop().fadeOut(500);
			})
			
			$(".zs").click(function(){
				if(age==1&&sex==1&&face==1){
					face=0;
					$(".img>img").attr("src","img/MMF.png");
					Isface();
				}else if(age==1&&sex==1&&face==0){
					face=1;
					$(".img>img").attr("src","img/MMZ.png");
					Isface();
				}else if(age==0&&sex==1&&face==1){
					face=0;
					$(".img>img").attr("src","img/CBF.png");
					Isface();
				}else if(age==0&&sex==1&&face==0){
					face=1;
					$(".img>img").attr("src","img/CBZ.png");
					Isface();
				}else if(age==1&&sex==0&&face==1){
					face=0;
					$(".img>img").attr("src","img/FMF.png");
					Isface();
				}else if(age==1&&sex==0&&face==0){
					face=1;
					$(".img>img").attr("src","img/FMZ.png");
					Isface();
				}else if(age==0&&sex==0&&face==1){
					face=0;
					$(".img>img").attr("src","img/CGF.png");
					Isface();
				}else if(age==0&&sex==0&&face==0){
					face=1;
					$(".img>img").attr("src","img/CGZ.png");
					Isface();
				}
			})
			
			
//			方法区域
				function Isface(){
					var src=$(".img>img").attr("src");
					var srMMF="img/MMF.png";
					var srFMF="img/FMF.png";
					var srCBF="img/CBF.png";
					var srCGF="img/CGF.png";
					if(src===srMMF||src===srFMF||src===srCBF||src===srCGF){
						face=0;
					}else{
						face=1;
					}
				}
	
	
				function getData(title,arr){
					var title=title;
					var Arr=arr;
					var headhtml="";
					var titlehtm=`
							<h4 class="title">${title}</h4>
					`;
					
					for (let i=0;i<Arr.length;i++) {
						headhtml+=`
							<li>${Arr[i]}<span>></span></li>
							`
					}
					$(".tit").html(titlehtm);
					$(".con-ul").html(headhtml);
				}
				
			function IsAc(){
				if(age==0){
					$(".head").css({"height": "20%","width": "35%","top": "5%","left":"30%","border-radius": "20%"});
					$(".neck").css({'height': '8%','width': '24%','top': '26%','left': '36%','border-radius': '50%'});
					$(".chest").css({height: '12%',width: '30%',top: '35%',left: '33%','border-radius': '50%'});
					$(".belly").css({height: '11%',width: '33%',top: '46%',left: '32%','border-radius': '50%'});
					$(".genitals").css({height:'11%',width: '36%',top: '57%',left: '30%','border-radius': '30% 30% 60% 60%'});
					$(".arm").css({height: '33%',width: '13%',top: '34%',left: '16%','border-radius': '0 20% 30% 0',transform: 'rotate(12deg)'});
					$(".arm2").css({height: '33%',width: '13%',top: '34%',right: '20%','border-radius': '0 20% 30% 0',transform: 'rotate(-12deg)'});
					$(".legs").css({'height': '32%',width: '36%',top:'66%',left: '31%',})
					}else if(age==1){
					$(".head").css({"height":"10%","width":"17%","top": "4%","left": "42%","border-radius": "20%"});
					$(".neck").css({'height': '5%','width': '20%','top': '15%','left': '40%','border-radius': '50%'})
					$(".chest").css({height: '8%',width: '28%',top: '22%',left: '36%','border-radius': '50%'});
					$(".belly").css({height: '11%',width: '25%',top: '32%',left: '37%','border-radius': '50%'});
					$(".genitals").css({height:'8.5%',width: '25%',top: '44%',left: '37%','border-radius': '20% 20% 50% 50%'});
					$(".arm").css({height: '38%',width: '13%',top: '20%',left: '19%','border-radius': '0 20% 30% 0',transform: 'rotate(12deg)'});
					$(".arm2").css({height: '38%',width: '13%',top:'20%',right: "19%",'border-radius':'0 20% 0 0',transform: 'rotate(-12deg)'});
					$(".legs").css({height: '43%',width: '25%',top: '53%',left: '37%',
})
}
}
			
			var tit=["下肢","耳眼口鼻","头部","胸部","腹部","皮肤","上肢","四肢","其他","颈部","生殖器","背部"];
			var lihtm='';
			for (var i=0;i<tit.length;i++) {
				lihtm+=`<li>${tit[i]}</li>`
			}
			$(".list").html(lihtm);
			
			let arr0=["髋关节疼痛", "膝关节疼痛", "踝部肿胀", "髋关节疼痛", "膝关节疼痛"];
			let arr1=["牙齿异常","听力下降","嘴疼","眼疼","流鼻血","口臭","鼻赛流涕","眼睛红","牙齿异常","眼屎多","流泪","视力下降","白瞳症","耳鸣","牙痛","听力下降","嘴唇紫钳"];
			let arr2=["腮腺肿大","耳痛","头痛","头晕","面部疼痛","语言障碍"];
			let arr3=["心悸","胸痛","咳嗽","肩部疼痛","呼吸困难","咯血","喘鸣"];
			let arr4=["呃逆","食欲异常","腹泻","胃肠胀气","恶心呕吐","呕血与黑便","反酸","腹痛","肝脏"];
			let arr5=["皮肤变色与色素痣","麟屑","皮肤溃疡","脱发","红斑","皮肤肿块","皮疹","皮肤损伤","脓疱疹","皮肤瘙痒"];
			let arr6=["手腕疼痛"];
			let arr7=["指甲问题","红肿"];
			let arr8=["高血压","感觉不适","抑郁","神经衰弱","肥胖","黄疽","周身疼痛","疲劳","不育","婴儿夜惊","低血压","消瘦","发热","焦虑","晕厥","思维和感觉混乱","震颤和抽搐","出血倾向","多汗症","失眠"];
			let arr9=["颈部疼痛或僵硬","咽喉疼痛","甲状腺肿大","吞咽困难","咳痰"];
			let arr10=["早泄","阳痿","因囊肿物","包皮长"];
			$(".list li").click(function() {
				var index=$(this).index();
				switch(index){
					case 0:
					getData2(tit[0],arr0);break;
					case 1:
					getData2(tit[1],arr1);break;
					case 2:
					getData2(tit[2],arr2);break;
					case 3:
					getData2(tit[3],arr3);break;
					case 4:
					getData2(tit[4],arr4);break;
					case 5:
					getData2(tit[5],arr5);break;
					case 6:
					getData2(tit[6],arr6);break;
					case 7:
					getData2(tit[7],arr7);break;
					case 8:
					getData2(tit[8],arr8);break;
					case 9:
					getData2(tit[9],arr9);break;
					case 10:
					getData2(tit[10],arr10);break;
					default:
					console.log("暂无数据");
				}
			})
			
			
			
			
			function getData2(title,arr){
					var title=title;
					var Arr=arr;
					var html="";
					var thtml=`
							<h4 class="title">${title}</h4>
					`;
					for (let i=0;i<Arr.length;i++) {
						html+=`
							<li>${Arr[i]}<span>></span></li>
							`
					}
					$(".tit2").html(thtml);
					$(".con-ul2").html(html);
					$(".zindex2").css("display", "block");
					$(".dis2").stop().animate({
						width: 'toggle'
					}, 500);
				}
			$(".cl2").click(function() {
				$(".dis2").stop().animate({
					width: 'hide'
				}, 500);
				$(".zindex2").stop().fadeOut(500);
			})